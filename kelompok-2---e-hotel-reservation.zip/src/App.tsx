/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Menu, 
  X, 
  Home, 
  Search, 
  Calendar, 
  CreditCard, 
  User, 
  LayoutDashboard, 
  LogOut, 
  ChevronRight,
  Heart,
  Star,
  CheckCircle2,
  FileText,
  UserPlus
} from 'lucide-react';

// Use Case Sections
type Section = 'home' | 'rooms' | 'how-to' | 'login' | 'register' | 'member' | 'admin';

export default function App() {
  const [activeSection, setActiveSection] = useState<Section>('home');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userRole, setUserRole] = useState<'member' | 'admin'>('member');

  const navLinks = [
    { name: 'Utama', id: 'home', icon: Home },
    { name: 'Kamar', id: 'rooms', icon: Search },
    { name: 'Cara Pesan', id: 'how-to', icon: Calendar },
  ];

  const handleLogin = (role: 'member' | 'admin') => {
    setUserRole(role);
    setIsLoggedIn(true);
    setActiveSection(role === 'member' ? 'member' : 'admin');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setActiveSection('home');
  };

  return (
    <div className="min-h-screen selection:bg-accent-soft selection:text-text-main relative overflow-hidden">
      {/* Decorative Background Elements */}
      <div className="absolute -top-40 -right-20 w-[400px] h-[400px] bg-decor-1 rounded-full blur-3xl opacity-50 -z-10" />
      <div className="absolute bottom-[10%] -left-20 w-[300px] h-[300px] bg-decor-2 rounded-full blur-3xl opacity-50 -z-10" />

      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-bg-main/80 backdrop-blur-xl border-b border-decor-1">
        <div className="max-w-7xl mx-auto px-6 py-6 flex justify-between items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2 cursor-pointer"
            onClick={() => setActiveSection('home')}
          >
            <span className="font-bold text-2xl tracking-tighter text-accent">KELOMPOK 2</span>
          </motion.div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-10">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => setActiveSection(link.id as Section)}
                className={`text-[12px] font-bold uppercase tracking-widest transition-colors hover:text-accent ${
                  activeSection === link.id ? 'text-accent border-b-2 border-accent' : 'text-text-dim'
                }`}
              >
                {link.name}
              </button>
            ))}
            
            {!isLoggedIn ? (
              <div className="flex items-center gap-6">
                <button 
                  onClick={() => setActiveSection('login')}
                  className="text-[12px] font-bold uppercase tracking-widest text-text-dim hover:text-text-main"
                >
                  Masuk
                </button>
                <button 
                  onClick={() => setActiveSection('register')}
                  className="bg-accent text-white px-8 py-3 rounded-full text-[12px] font-bold uppercase tracking-widest shadow-[0_8px_20px_rgba(255,138,138,0.3)] hover:scale-105 transition-transform"
                >
                  Daftar
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-6">
                <button 
                  onClick={() => setActiveSection(userRole)}
                  className="text-[12px] font-bold uppercase tracking-widest text-text-dim hover:text-text-main flex items-center gap-2"
                >
                   Profil
                </button>
                <button 
                  onClick={handleLogout}
                  className="text-text-dim hover:text-accent transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          {/* Mobile Menu Trigger */}
          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </nav>

      <main className="pt-24 pb-20 px-6 max-w-7xl mx-auto">
        <AnimatePresence mode="wait">
          {activeSection === 'home' && (
            <motion.div key="home">
              <HomeSection onExplore={() => setActiveSection('rooms')} />
            </motion.div>
          )}
          {activeSection === 'rooms' && (
            <motion.div key="rooms">
              <RoomsSection />
            </motion.div>
          )}
          {activeSection === 'how-to' && (
            <motion.div key="how-to">
              <HowToSection />
            </motion.div>
          )}
          {activeSection === 'login' && (
            <motion.div key="login">
              <AuthSection type="login" onLogin={handleLogin} />
            </motion.div>
          )}
          {activeSection === 'register' && (
            <motion.div key="register">
              <AuthSection type="register" onLogin={() => setActiveSection('login')} />
            </motion.div>
          )}
          {activeSection === 'member' && (
            <motion.div key="member">
              <MemberDashboard />
            </motion.div>
          )}
          {activeSection === 'admin' && (
            <motion.div key="admin">
              <AdminDashboard />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="bg-surface py-20 px-6 border-t border-decor-1">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start gap-12">
          <div className="space-y-6 max-w-sm">
            <span className="font-bold text-2xl tracking-tighter text-accent">KELOMPOK 2</span>
            <p className="text-[16px] text-text-dim leading-relaxed">I design aesthetic digital experiences that feel warm, friendly, and human.</p>
          </div>
          <div className="flex flex-col md:flex-row gap-12 md:gap-24">
             <div className="space-y-4">
                <p className="text-[10px] font-bold uppercase tracking-widest text-accent">Studio</p>
                <div className="flex flex-col gap-2 text-sm font-medium text-text-dim">
                   <a href="#" className="hover:text-accent transition-colors">About</a>
                   <a href="#" className="hover:text-accent transition-colors">Process</a>
                   <a href="#" className="hover:text-accent transition-colors">Showcase</a>
                </div>
             </div>
             <div className="space-y-4">
                <p className="text-[10px] font-bold uppercase tracking-widest text-accent">Connect</p>
                <div className="flex flex-col gap-2 text-sm font-medium text-text-dim">
                   <a href="#" className="hover:text-accent transition-colors">Instagram</a>
                   <a href="#" className="hover:text-accent transition-colors">TikTok</a>
                   <a href="#" className="hover:text-accent transition-colors">Twitter</a>
                </div>
             </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function HomeSection({ onExplore }: { onExplore: () => void }) {
  return (
    <motion.section 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="flex flex-col md:flex-row items-center gap-16 py-20"
    >
      <div className="flex-1 space-y-8">
        <span className="inline-block px-4 py-1.5 bg-accent-soft text-accent rounded-full text-[12px] font-bold uppercase tracking-widest">
          Featured Portfolio
        </span>
        <motion.h1 
          className="text-5xl md:text-7xl font-bold leading-[1.1] text-text-heading tracking-tight"
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          E-Hotel Reservation
        </motion.h1>
        <p className="text-[18px] text-text-dim max-w-md leading-relaxed">
          I design aesthetic digital experiences that feel warm, friendly, and human. Specialized in UI/UX and Brand Identity.
        </p>
        <div className="flex items-center gap-4">
          <button 
            onClick={onExplore}
            className="bg-accent text-white px-10 py-5 rounded-full font-bold shadow-[0_8px_20px_rgba(255,138,138,0.3)] hover:scale-105 active:scale-95 transition-all flex items-center gap-2 uppercase text-[12px] tracking-widest"
          >
            Eksplor Kamar <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
      <div className="flex-1 relative">
        <motion.div 
          className="w-full aspect-square bg-[#FFD8CC] rounded-[48px] overflow-hidden shadow-2xl relative"
          transition={{ type: 'spring', stiffness: 200 }}
        >
          <img 
            src="https://picsum.photos/seed/cozy-room/1200/1200" 
            alt="Cozy Room" 
            className="w-full h-full object-cover transition-all duration-700"
            referrerPolicy="no-referrer"
          />
        </motion.div>
      </div>
    </motion.section>
  );
}

function RoomsSection() {
  const rooms = [
    { name: 'Suite Vanilla', price: 'Rp 450k', tags: ['Minimalis', 'WiFi'], img: 'https://picsum.photos/seed/room-1/800/800' },
    { name: 'Deluxe Creamy', price: 'Rp 650k', tags: ['Garden View', 'Minibar'], img: 'https://picsum.photos/seed/room-2/800/800' },
    { name: 'Executive Rose', price: 'Rp 950k', tags: ['Balcony', 'King Bed'], img: 'https://picsum.photos/seed/room-3/800/800' },
  ];

  return (
    <motion.section 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-16 py-20"
    >
      <div className="text-center space-y-4">
        <h2 className="text-4xl font-bold text-text-heading">Pilih Kenyamananmu</h2>
        <div className="w-16 h-1 bg-accent mx-auto rounded-full" />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
        {rooms.map((room, idx) => (
          <motion.div 
            key={room.name}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.15 }}
            className="bg-surface rounded-[32px] overflow-hidden shadow-[0_10px_30px_rgba(255,138,138,0.1)] transition-all border border-[#FDF0E9] group"
          >
            <div className="h-48 overflow-hidden p-6">
              <img src={room.img} alt={room.name} className="w-full h-full object-cover rounded-[24px] group-hover:scale-110 transition-transform duration-700" referrerPolicy="no-referrer" />
            </div>
            <div className="p-8 space-y-4">
              <div className="flex justify-between items-start">
                <h3 className="text-xl font-bold text-text-heading">{room.name}</h3>
                <span className="text-text-dim font-medium text-sm">{room.price}/malam</span>
              </div>
              <div className="flex gap-2">
                {room.tags.map(tag => (
                  <span key={tag} className="text-[10px] uppercase tracking-widest font-bold px-3 py-1 bg-decor-1 rounded-full text-text-dim">{tag}</span>
                ))}
              </div>
              <button className="w-full py-4 rounded-full bg-accent text-white shadow-[0_8px_20px_rgba(255,138,138,0.2)] hover:scale-105 transition-transform font-bold text-sm uppercase tracking-widest">Pesan Sekarang</button>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.section>
  );
}

function HowToSection() {
  const steps = [
    { title: 'Tentukan Tanggal', desc: 'Pilih jadwal staycation serumu.', icon: Calendar, color: 'dot-pink' },
    { title: 'Pilih Kamar Cantik', desc: 'Detail tipe kamar yang manis.', icon: Search, color: 'dot-yellow' },
    { title: 'Pembayaran Mudah', desc: 'Transfer atau Kartu Kredit aman.', icon: CreditCard, color: 'dot-mint' },
    { title: 'Selesai!', desc: 'Cek email untuk bukti reservasi.', icon: CheckCircle2, color: 'dot-pink' },
  ];

  return (
    <motion.section 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="py-20 space-y-16"
    >
       <div className="bg-surface rounded-[40px] p-12 md:p-20 shadow-[0_10px_30px_rgba(255,138,138,0.05)] relative overflow-hidden border border-[#FDF0E9]">
        <div className="relative z-10 space-y-16">
          <div className="space-y-4 max-w-xl">
             <span className="badge inline-block px-4 py-1 bg-accent-soft text-accent rounded-full text-[12px] font-bold uppercase tracking-widest mb-4">Our Process</span>
             <h2 className="text-5xl font-bold leading-tight text-text-heading">Langkah Mudah Memesan Kamar.</h2>
             <p className="text-text-dim text-[16px]">I design aesthetic digital experiences that feel warm, friendly, and human.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            {steps.map((step, idx) => (
              <div key={step.title} className="space-y-6">
                <div className="w-12 h-12 bg-[#F9F4F0] rounded-full flex items-center justify-center text-accent">
                  <step.icon className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-xl text-text-heading">{step.title}</h3>
                <p className="text-sm text-text-dim leading-relaxed">{step.desc}</p>
              </div>
            ))}
          </div>

          <div className="pt-12 border-t border-decor-1 flex flex-col md:flex-row gap-12">
            <div className="flex-1 space-y-4">
              <h4 className="font-bold text-xl text-text-heading">Metode Pembayaran</h4>
              <p className="text-sm text-text-dim leading-relaxed">Kami mendukung Transfer Bank (BCA, Mandiri), E-Wallet (GoPay, OVO), dan Kartu Kredit berlogo Visa/Mastercard.</p>
            </div>
            <div className="flex-1">
               <a href="#" className="bg-accent text-white px-8 py-4 rounded-full font-bold shadow-[0_8px_20px_rgba(255,138,138,0.2)] hover:scale-105 transition-transform inline-block uppercase text-[12px] tracking-widest">Contact Support</a>
            </div>
          </div>
        </div>
      </div>
    </motion.section>
  );
}

function AuthSection({ type, onLogin }: { type: 'login' | 'register', onLogin: (role: 'member' | 'admin') => void }) {
  const [email, setEmail] = useState('');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (email.includes('admin')) {
      onLogin('admin');
    } else {
      onLogin('member');
    }
  };

  return (
    <motion.section 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-md mx-auto py-20"
    >
      <div className="bg-surface rounded-[40px] p-12 shadow-[0_20px_40px_rgba(255,138,138,0.1)] border border-[#FDF0E9] space-y-10">
        <div className="text-center space-y-3">
          <h2 className="text-4xl font-bold text-text-heading">{type === 'login' ? 'Welcome Back' : 'Create Account'}</h2>
          <p className="text-sm text-text-dim uppercase tracking-widest font-bold font-sans">CozyRest Digital Experiences</p>
        </div>

        <form className="space-y-6" onSubmit={handleSubmit}>
          <div className="space-y-2">
            <label className="text-[12px] uppercase tracking-widest font-bold text-text-dim ml-2">Email Address</label>
            <input 
              type="email" 
              required
              placeholder="hello@studio.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-6 py-5 rounded-[20px] bg-[#F9F4F0] border-none focus:ring-2 focus:ring-accent/30 placeholder:text-text-dim/30"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[12px] uppercase tracking-widest font-bold text-text-dim ml-2">Secure Password</label>
            <input 
              type="password" 
              required
              placeholder="••••••••"
              className="w-full px-6 py-5 rounded-[20px] bg-[#F9F4F0] border-none focus:ring-2 focus:ring-accent/30 placeholder:text-text-dim/30"
            />
          </div>
          <button 
            type="submit"
            className="w-full py-6 rounded-full bg-accent text-white font-bold shadow-[0_8px_20px_rgba(255,138,138,0.3)] hover:scale-[1.02] active:scale-95 transition-all text-[14px] uppercase tracking-widest"
          >
            {type === 'login' ? 'Access App' : 'Get Started'}
          </button>
        </form>

        <p className="text-center text-[12px] text-text-dim font-medium">
           {type === 'login' ? 'Need an account? Sign up today.' : 'Already a member? Login here.'}
        </p>
      </div>
    </motion.section>
  );
}

function MemberDashboard() {
  const reservations = [
    { id: 'CZ-9021', room: 'Suite Vanilla', checkin: '12 Mei 2026', status: 'Pending Pembayaran' }
  ];

  return (
    <motion.section 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-16 py-20"
    >
      <div className="flex flex-col md:flex-row justify-between items-end gap-6">
        <div className="space-y-2">
          <h2 className="text-4xl font-bold text-text-heading leading-tight">Member Workspace</h2>
          <p className="text-text-dim text-[16px]">Manage your bookings and visual identity.</p>
        </div>
        <button className="bg-accent text-white px-8 py-4 rounded-full font-bold shadow-[0_8px_20px_rgba(255,138,138,0.2)] hover:scale-105 transition-transform flex items-center gap-2 uppercase text-[12px] tracking-widest">
           Reservasi Baru
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        {/* Active Reservations */}
        <div className="bg-surface rounded-[40px] p-10 shadow-[0_10px_30px_rgba(255,138,138,0.1)] space-y-8 border border-[#FDF0E9]">
           <h3 className="font-bold text-xl text-text-heading flex items-center gap-2">Daftar Reservasi</h3>
           {reservations.map(res => (
             <div key={res.id} className="p-8 bg-[#F9F4F0] rounded-[32px] space-y-6">
                <div className="flex justify-between items-start">
                   <div>
                     <p className="text-[10px] font-bold text-accent uppercase tracking-widest mb-1">{res.id}</p>
                     <h4 className="font-bold text-lg text-text-heading">{res.room}</h4>
                   </div>
                   <span className="text-[10px] bg-accent-soft text-accent px-4 py-1.5 rounded-full font-bold uppercase tracking-widest">{res.status}</span>
                </div>
                <div className="flex justify-between items-center text-sm font-medium">
                  <span className="text-text-dim">{res.checkin}</span>
                  <div className="flex gap-3">
                     <button className="p-3 bg-surface rounded-xl shadow-sm hover:bg-accent hover:text-white transition-all"><CreditCard className="w-4 h-4" /></button>
                     <button className="p-3 bg-surface rounded-xl shadow-sm hover:bg-accent hover:text-white transition-all"><FileText className="w-4 h-4" /></button>
                  </div>
                </div>
             </div>
           ))}
        </div>

        {/* Payment Confirmation Form Mockup */}
        <div className="bg-text-heading text-white rounded-[40px] p-10 shadow-2xl space-y-10">
           <div className="space-y-2">
              <h3 className="text-2xl font-bold">Secure Billing</h3>
              <p className="text-white/40 text-[14px]">I design aesthetic digital experiences that feel warm and friendly.</p>
           </div>
           
           <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] uppercase font-bold text-white/30 ml-2 tracking-widest">Reservation ID</label>
                <div className="w-full p-5 rounded-[20px] bg-white/5 border border-white/10 flex justify-between items-center">
                   <span className="font-bold">CZ-9021</span>
                   <ChevronRight className="w-4 h-4 text-white/20" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] uppercase font-bold text-white/30 ml-2 tracking-widest">Upload Receipt</label>
                <div className="w-full h-40 border-2 border-dashed border-white/10 rounded-[20px] flex items-center justify-center flex-col gap-3 group cursor-pointer hover:bg-white/5 transition-all">
                   <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center group-hover:bg-accent transition-colors">
                     <FileText className="w-5 h-5" />
                   </div>
                   <span className="text-[12px] font-bold text-white/30 uppercase tracking-widest">Select Files</span>
                </div>
              </div>
              <button className="w-full py-5 bg-accent text-white rounded-full font-bold shadow-[0_8px_20px_rgba(255,138,138,0.3)] hover:scale-[1.02] active:scale-95 transition-all uppercase text-[12px] tracking-widest">Kirim Konfirmasi</button>
           </div>
        </div>
      </div>
    </motion.section>
  );
}

function AdminDashboard() {
  const stats = [
    { label: 'Kamar Tersedia', val: '12', icon: Home },
    { label: 'Member Baru', val: '+4', icon: UserPlus },
    { label: 'Pendapatan', val: '22.8M', icon: Star },
  ];

  const recentActivities = [
    { type: 'Reservation', user: 'Clarissa M.', time: '2 menit lalu' },
    { type: 'Payment', user: 'Dimas P.', time: '15 menit lalu' },
    { type: 'New Member', user: 'Sarah W.', time: '1 jam lalu' },
  ];

  return (
    <motion.section 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="space-y-16 py-20"
    >
      <div className="flex items-center gap-6">
        <div className="w-14 h-14 bg-text-heading rounded-2xl flex items-center justify-center text-white shadow-xl">
          <LayoutDashboard className="w-6 h-6" />
        </div>
        <div className="space-y-1">
          <h2 className="text-4xl font-bold text-text-heading leading-tight">Admin Intelligence</h2>
          <p className="text-text-dim text-[16px]">Monitor seluruh aktivitas CozyRest Studio.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {stats.map(s => (
          <div key={s.label} className="bg-surface p-10 rounded-[32px] shadow-[0_10px_30px_rgba(255,138,138,0.1)] border border-[#FDF0E9] flex items-center gap-8 group hover:scale-[1.02] transition-transform">
            <div className="w-16 h-16 bg-[#F9F4F0] rounded-full flex items-center justify-center text-accent group-hover:bg-accent group-hover:text-white transition-colors">
              <s.icon className="w-7 h-7" />
            </div>
            <div>
              <p className="text-[10px] font-bold text-text-dim uppercase tracking-widest mb-2 leading-none">{s.label}</p>
              <p className="text-4xl font-bold text-text-heading">{s.val}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
         <div className="bg-surface rounded-[40px] p-10 border border-[#FDF0E9] shadow-sm space-y-10">
            <h3 className="font-bold text-2xl text-text-heading">Kelola Data & Laporan</h3>
            <div className="grid grid-cols-2 gap-6">
               {['Data Member', 'Data Kamar', 'Kategori', 'Reservasi', 'Pembayaran', 'Laporan'].map(menu => (
                 <button key={menu} className="p-6 bg-[#F9F4F0] rounded-[24px] text-left hover:bg-accent-soft hover:text-accent transition-all font-bold text-[14px] flex items-center justify-between group uppercase tracking-widest">
                   {menu}
                   <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-all translate-x-[-10px] group-hover:translate-x-0" />
                 </button>
               ))}
            </div>
         </div>

         <div className="space-y-8">
            <h3 className="font-bold text-2xl px-4 text-text-heading">Aktivitas Terbaru</h3>
            <div className="space-y-4">
               {recentActivities.map((act, idx) => (
                 <motion.div 
                    key={idx}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className="flex justify-between items-center p-8 bg-surface border border-[#FDF0E9] rounded-[32px] shadow-sm"
                 >
                   <div className="flex items-center gap-6">
                      <div className="w-12 h-12 bg-accent-soft rounded-full flex items-center justify-center text-accent">
                        <CheckCircle2 className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="font-bold text-text-heading">{act.user}</p>
                        <p className="text-[10px] text-text-dim uppercase font-bold tracking-widest mt-1">{act.type}</p>
                      </div>
                   </div>
                   <span className="text-[10px] text-text-dim/50 font-bold uppercase tracking-widest">{act.time}</span>
                 </motion.div>
               ))}
            </div>
            <button className="w-full py-5 bg-text-heading text-white rounded-full font-bold shadow-xl flex items-center justify-center gap-3 uppercase text-[12px] tracking-widest">
               Lihat Seluruh Laporan <ChevronRight className="w-4 h-4" />
            </button>
         </div>
      </div>
    </motion.section>
  );
}
