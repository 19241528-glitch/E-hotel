# Kelompok 2 - E-Hotel Reservation

Project ini adalah prototipe sistem **E-Hotel Reservation** yang dikembangkan oleh Kelompok 2. Desain menggunakan tema *Vibrant Palette* yang estetik, modern, dan ramah pengguna.

## 🚀 Fitur Utama
- **Landing Page**: Eksplorasi tipe kamar dengan visual yang memikat.
- **Member Dashboard**: Kelola reservasi dan konfirmasi pembayaran dengan antarmuka yang ramah pengguna.
- **Admin Panel**: Dashboard intelijen untuk monitor aktivitas, data member, dan laporan.

## 🛠️ Stack Teknologi
- **Frontend**: React 19 + TypeScript
- **Styling**: Tailwind CSS 4
- **Animations**: Framer Motion
- **Icons**: Lucide React
- **Build Tool**: Vite

## 📦 Instalasi

1. Clone repository ini:
   ```bash
   git clone <repository-url>
   ```

2. Instal dependensi:
   ```bash
   npm install
   ```

3. Jalankan server pengembangan:
   ```bash
   npm run dev
   ```

4. Buka di browser:
   `http://localhost:3000`

## 🎨 Panduan Tema (Vibrant Palette)
Prototipe ini menggunakan palet warna vibran yang hangat:
- **Background**: `#FEFAF6` (Warm Ivory)
- **Accent**: `#FF8A8A` (Vibrant Coral)
- **Surface**: `#FFFFFF`
- **Typography**: Inter (Sans) & Cormorant Garamond (Serif)

---
*Dibuat dengan ❤️ oleh Kelompok 2*
